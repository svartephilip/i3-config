# Double Door Datapack
This datapack add ability to open two door at the same time.
